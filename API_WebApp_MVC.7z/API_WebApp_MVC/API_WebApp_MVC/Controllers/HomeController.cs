﻿using API_WebApp_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace API_WebApp_MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        //public IActionResult Index()
        //{
        //    var list = new List<Student>();
        //    var st1 = new Student();
        //    st1.StudentId = 1;
        //    st1.Email = "kamil@interia.pl";
        //    st1.FirstName = "Kamil";
        //    st1.LastName = "Struzik";
        //    list.Add(st1);
        //    var st2 = new Student();
        //    st2.StudentId = 2;
        //    st2.Email = "jan@interia.pl";
        //    st2.FirstName = "Jan";
        //    st2.LastName = "Nowak";
        //    list.Add(st2);
        //    var st3 = new Student();
        //    st3.StudentId = 3;
        //    st3.Email = "adam@interia.pl";
        //    st3.FirstName = "Adam";
        //    st3.LastName = "Szymański";
        //    list.Add(st3);
        //    return View(list);
        //}

        [HttpGet]
        public IActionResult Index( int Id )
        {
            Student st = new Student();
            var list = new List<Student>();

            if (Id == 1)
            {
                st.StudentId = 1;
                st.Email = "kamil@interia.pl";
                st.FirstName = "Kamil";
                st.LastName = "Struzik";
                list.Add(st);
            }
            if (Id == 2)
            {
                st.StudentId = 2;
                st.Email = "jan@interia.pl";
                st.FirstName = "Jan";
                st.LastName = "Nowak";
                list.Add(st);
            }
            if (Id == 3)
            {
                st.StudentId = 3;
                st.Email = "adam@interia.pl";
                st.FirstName = "Adam";
                st.LastName = "Szymański";
                list.Add(st);

            }
            if (Id == 0)
            {
                var st1 = new Student();
                st1.StudentId = 1;
                st1.Email = "kamil@interia.pl";
                st1.FirstName = "Kamil";
                st1.LastName = "Struzik";
                list.Add(st1);
                var st2 = new Student();
                st2.StudentId = 2;
                st2.Email = "jan@interia.pl";
                st2.FirstName = "Jan";
                st2.LastName = "Nowak";
                list.Add(st2);
                var st3 = new Student();
                st3.StudentId = 3;
                st3.Email = "adam@interia.pl";
                st3.FirstName = "Adam";
                st3.LastName = "Szymański";
                list.Add(st3);
            }
            return View(list);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}