﻿using API_WebApp_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace API_WebApp_MVC.Controllers
{
    public class StudentsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Details(int Id)
        {
            Detail detail = new Detail();
            detail.StudentId=Id;
            if(Id==1)
            {
                detail.StudentId = 1;
                detail.Address = "Postępu 10";
                detail.Phone = "8764387642";
                detail.DateOfBirth = "2010-06-10";
                detail.Gender = "Man";
                detail.Nationality = "United States";
                detail.GuardianName = "Unknown";

            }
            if (Id == 2)
            {
                detail.StudentId = 2;
                detail.Address = "Krakowska 2";
                detail.Phone = "654654543";
                detail.DateOfBirth = "1989-01-01";
                detail.Gender = "Man";
                detail.Nationality = "Polish";
                detail.GuardianName = "Empty";
            }
            if (Id == 3)
            {
                detail.StudentId = 3;
                detail.Address = "Cybernetyki 3";
                detail.Phone = "765765765";
                detail.DateOfBirth = "1999-01-01";
                detail.Gender = "Man";
                detail.Nationality = "German";
                detail.GuardianName = "No Guardian";
            }
            return View(detail);
            //return new ContentResult { Content = StudId.ToString() };
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Student student)
        {
            //return View();
            //tu powinno być zapisanie studenta do bazy
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            Student st = new Student();
            st.StudentId = Id;

            if (st.StudentId == 1)
            {
                st.StudentId = 1;
                st.Email = "kamil@interia.pl";
                st.FirstName = "Kamil";
                st.LastName = "Struzik";
            }
            if (st.StudentId == 2)
            {
                st.StudentId = 2;
                st.Email = "jan@interia.pl";
                st.FirstName = "Jan";
                st.LastName = "Nowak";
            }
            if (st.StudentId == 3)
            {
                st.StudentId = 3;
                st.Email = "adam@interia.pl";
                st.FirstName = "Adam";
                st.LastName = "Szymański";
 
            }
            return View(st);
        }

        [HttpPost]
        public IActionResult Edit(Student student)
        {
            //return View();
            //tu powinno być zupdateowanie studenta w bazie
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Delete()
        {
            //return View();
            //tu powinno być zapisanie studenta do bazy
            return RedirectToAction("Index", "Home");
        }
    }
}
